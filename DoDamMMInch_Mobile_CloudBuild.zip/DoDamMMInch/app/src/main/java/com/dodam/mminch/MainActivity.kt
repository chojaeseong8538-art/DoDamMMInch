package com.dodam.mminch


import androidx.activity.ComponentActivity
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.DecimalFormat
import java.util.Locale
import kotlin.math.round

class MainActivity : ComponentActivity() {
    private lateinit var imageView: ImageView
    private lateinit var results: LinearLayout
    private lateinit var status: TextView
    private lateinit var scanButton: Button
    private var sourceBitmap: Bitmap? = null
    private var selectedColors = mutableSetOf("blue")
    private var decimalPlaces = 5.0
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { stream -> sourceBitmap = BitmapFactory.decodeStream(stream) }
                showPhotoAndEnableScan()
            } catch (e: Exception) { status.text = "사진을 열 수 없습니다: ${e.message}" }
        }
    }
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val bmp = result.data?.extras?.get("data") as? Bitmap
            if (bmp != null) { sourceBitmap = bmp; showPhotoAndEnableScan() }
            else status.text = "카메라 사진을 가져오지 못했습니다. 갤러리에서 원본 사진을 선택해 주세요."
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }


    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 18); setBackgroundColor(Color.rgb(246,247,250)) }
        val title = TextView(this).apply { text = "도담 MM → INCH"; textSize = 24f; setTextColor(Color.rgb(25,55,90)); setPadding(0,0,0,6) }
        root.addView(title)
        root.addView(TextView(this).apply { text = "수기 도면 치수 인식 · 색상 필터" ; textSize=14f; setTextColor(Color.DKGRAY) })
        val colorsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0,16,0,8) }
        colorsRow.addView(colorToggle("파란색", "blue", Color.rgb(35,105,235)))
        colorsRow.addView(colorToggle("보라색", "purple", Color.rgb(150,65,200)))
        colorsRow.addView(colorToggle("빨간색", "red", Color.rgb(220,55,55)))
        colorsRow.addView(colorToggle("기타", "other", Color.DKGRAY))
        root.addView(colorsRow)
        val photoRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,4,0,8) }
        photoRow.addView(Button(this).apply { text = "📷 촬영"; setOnClickListener { launchCamera() } }, LinearLayout.LayoutParams(0, -2, 1f))
        photoRow.addView(Button(this).apply { text = "🖼 사진 선택"; setOnClickListener { galleryLauncher.launch("image/*") } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(photoRow)
        imageView = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE) }
        root.addView(imageView, LinearLayout.LayoutParams(-1, 0, 2f))
        scanButton = Button(this).apply { text = "선택 색상 수기 치수 인식"; isEnabled = false; setOnClickListener { runOcr() } }
        root.addView(scanButton)
        val settingsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        settingsRow.addView(TextView(this).apply { text = "표시 자릿수  "; setTextColor(Color.DKGRAY) } )
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("3자리", "4자리", "5자리", "6자리"))
        spinner.setSelection(2)
        spinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { decimalPlaces = (position+3).toDouble() }
        }
        settingsRow.addView(spinner)
        root.addView(settingsRow)
        status = TextView(this).apply { text = "사진을 촬영하거나 선택한 뒤 인식을 눌러주세요."; textSize=14f; setTextColor(Color.rgb(90,90,90)); setPadding(0,10,0,8) }
        root.addView(status)
        val resultTitle = TextView(this).apply { text = "인식 / 변환 결과 (값을 눌러 수정 가능)"; textSize=17f; setTextColor(Color.rgb(25,55,90)); setPadding(0,8,0,8) }
        root.addView(resultTitle)
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(results) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 2f))
        root.addView(Button(this).apply { text = "결과 전체 복사"; setOnClickListener { copyResults() } })
        setContentView(root)
    }

    private fun colorToggle(label: String, key: String, color: Int): Button = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(if (selectedColors.contains(key)) color else Color.GRAY)
        setOnClickListener {
            if (selectedColors.contains(key)) selectedColors.remove(key) else selectedColors.add(key)
            setBackgroundColor(if (selectedColors.contains(key)) color else Color.GRAY)
            status.text = "선택 색상: ${selectedColors.joinToString()}"
        }
    }

    private fun launchCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) cameraLauncher.launch(intent)
        else status.text = "사용 가능한 카메라 앱이 없습니다. 사진 선택을 이용하세요."
    }

    private fun showPhotoAndEnableScan() {
        imageView.setImageBitmap(sourceBitmap)
        scanButton.isEnabled = true
        status.text = "사진 준비 완료. 인식 버튼을 눌러 분석하세요."
    }

    private fun runOcr() {
        val bitmap = sourceBitmap ?: return
        status.text = "색상 필터 및 OCR 분석 중..."
        scanButton.isEnabled = false
        val filtered = colorFilter(bitmap, selectedColors)
        recognizer.process(InputImage.fromBitmap(filtered, 0))
            .addOnSuccessListener { visionText ->
                results.removeAllViews()
                val candidates = mutableListOf<String>()
                for (block in visionText.textBlocks) for (line in block.lines) candidates.add(line.text)
                val numbers = candidates.flatMap { extractNumbers(it) }.distinct()
                if (numbers.isEmpty()) {
                    status.text = "숫자를 찾지 못했습니다. 색상 선택을 바꾸거나 사진을 다시 촬영해 주세요."
                    addResultRow("인식된 숫자 없음", null)
                } else {
                    status.text = "${numbers.size}개 치수 후보 인식. 가공 전 도면과 반드시 대조하세요."
                    numbers.forEach { addResultRow(it, it.toDoubleOrNull()) }
                }
                scanButton.isEnabled = true
            }
            .addOnFailureListener { e -> status.text = "OCR 오류: ${e.localizedMessage}"; scanButton.isEnabled = true }
    }

    // HSV color mask: suppress non-selected ink while retaining selected pen strokes.
    private fun colorFilter(src: Bitmap, selected: Set<String>): Bitmap {
        if (selected.contains("other") || selected.isEmpty()) return src
        val w = src.width; val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w*h); src.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val c = pixels[i]
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            val hsv = FloatArray(3); Color.RGBToHSV(r,g,b,hsv)
            val hue = hsv[0]; val sat = hsv[1]; val value = hsv[2]
            val blue = hue in 185f..255f && sat > .18f && value < .98f
            val purple = hue in 260f..325f && sat > .18f && value < .98f
            val red = (hue <= 18f || hue >= 345f) && sat > .2f && value < .98f
            val keep = (selected.contains("blue") && blue) || (selected.contains("purple") && purple) || (selected.contains("red") && red)
            pixels[i] = if (keep) Color.BLACK else Color.WHITE
        }
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }

    private fun extractNumbers(text: String): List<String> {
        // Avoid isolated drawing labels; keep numeric dimensions with decimal point when OCR sees one.
        val normalized = text.replace(',', '.')
        val regex = Regex("(?<![A-Za-z])[-+]?\\d{1,4}(?:\\.\\d{1,6})?(?![A-Za-z])")
        return regex.findAll(normalized).map { it.value }.filter { it.replace(".","").length >= 2 }.toList()
    }

    private fun addResultRow(raw: String, value: Double?) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,3,0,3) }
        val edit = EditText(this).apply { setText(raw); textSize=16f; setSingleLine(true); setTextColor(Color.rgb(30,80,145)); hint="MM 치수" }
        row.addView(edit, LinearLayout.LayoutParams(0, -2, 1.15f))
        val converted = TextView(this).apply { textSize=16f; setTextColor(Color.rgb(30,115,60)); gravity=Gravity.CENTER_VERTICAL; setPadding(8,0,8,0) }
        fun update() { val n=edit.text.toString().trim().toDoubleOrNull(); converted.text = if (n != null) "= ${format(n/25.4)} in" else "= 확인 필요" }
        update(); edit.addTextChangedListener(object: android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { update() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        row.addView(converted, LinearLayout.LayoutParams(0, -2, 1f))
        results.addView(row)
    }
    private fun format(v: Double): String {
        val pattern = "0." + "0".repeat(decimalPlaces.toInt())
        return DecimalFormat(pattern).format(v)
    }
    private fun copyResults() {
        val lines = mutableListOf<String>()
        for (i in 0 until results.childCount) {
            val row = results.getChildAt(i) as? LinearLayout ?: continue
            val edit = row.getChildAt(0) as? EditText ?: continue
            val mm = edit.text.toString().toDoubleOrNull() ?: continue
            lines.add("${edit.text} mm = ${format(mm/25.4)} in")
        }
        if (lines.isEmpty()) { status.text = "복사할 변환값이 없습니다."; return }
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("MM-INCH", lines.joinToString("\n")))
        status.text = "${lines.size}개 결과를 클립보드에 복사했습니다."
    }
}
